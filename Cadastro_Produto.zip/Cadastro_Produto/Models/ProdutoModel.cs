namespace Cadastro_Produto.Models
{
    public class ProdutoModel
    {
        public string Id {get;set;} =  Guid.NewGuid().ToString();
        public string Descricao {get;set;}
        public int Quantidade {get;set;}
        public decimal Valor {get;set;}
    }
}