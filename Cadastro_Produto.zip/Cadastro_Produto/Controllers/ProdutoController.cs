using Cadastro_Produto.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Text.Json;

namespace Cadastro_Produto.Controllers
{
    public class ProdutoController : Controller
    {
        public static List<ProdutoModel> db = new List<ProdutoModel>();
        public IActionResult Cadastrar(ProdutoModel produto)
        {
            ProdutoModel prod = db.Find(p => p.Id == produto.Id );
            if(prod != null){
               var index = db.FindIndex(a => a.Id == produto.Id);
                db[index] = produto;
                return RedirectToAction("Listar");
            }else{

                db.Add(produto);
                return RedirectToAction("Listar");
            }
        }

        public IActionResult Listar()
        {
          return View(db);
        }

        public IActionResult SalvarTxt(ProdutoModel produto)
        {
            string path = @"ListaProdutos.txt";
           
            
    
            using (StreamWriter sw = System.IO.File.CreateText(path))
            {
                 
              foreach (var item in db)
              {
                 sw.WriteLine($"Id:{item.Id}, Produto:{item.Descricao}, Quantidade:{item.Quantidade}, Valor:R${item.Valor};");
              }
               
            }
          
            return RedirectToAction("Listar");
             
        }

        public IActionResult Editar(string id)
        {
            ProdutoModel produto = db.Find(p => p.Id == id );
            if(produto != null){
                return View(produto);
            }
            else{
                return RedirectToAction("Listar");
            }

            
        }

        public IActionResult Excluir(string id)
        {
            ProdutoModel produto = db.Find(p => p.Id == id );
            if(produto != null){
               db.Remove(produto);
               return RedirectToAction("Listar");
            }
            else{
                return RedirectToAction("Listar");
            }
        }

        
    }
}