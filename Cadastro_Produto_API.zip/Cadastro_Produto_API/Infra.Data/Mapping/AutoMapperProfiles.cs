using AutoMapper;
using Domain.Entity;
using Domain.Models;

namespace Infra.Data.Mapping
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<Produto, ProdutoModel>().ReverseMap();
        }
    }
}