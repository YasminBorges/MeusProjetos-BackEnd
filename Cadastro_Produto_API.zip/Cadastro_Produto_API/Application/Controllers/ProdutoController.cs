using AutoMapper;
using Domain.Entity;
using Domain.Interfaces;
using Domain.Models;
using Microsoft.AspNetCore.Mvc;

namespace Application.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProdutoController : ControllerBase
    {
        private readonly IBaseService<Produto> _service;
        private readonly IMapper _mapper;

        public ProdutoController(IBaseService<Produto> service, IMapper mapper)
        {
            _service = service;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var produtos = await _service.GetAll();
            var results = _mapper.Map<Produto[]>(produtos);
            return Ok(results);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> GetById(string Id)
        {
             var produto = await _service.GetById(Id);
            var results = _mapper.Map<Produto>(produto);
            return Ok(results);
        }

        [HttpPost]
        public async Task<IActionResult> Post(ProdutoModel produto)
        {
             var prod = _mapper.Map<Produto>(produto);
             _service.Add(prod);

             if (await _service.SaveChangesAsync())
                return Created($"api/Produto/{produto.Id}", produto);
             

            return BadRequest();
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put(string Id,ProdutoModel model)
        {
            var produto = await _service.GetById(Id);
            if(produto == null) return NotFound();

            _mapper.Map(model,produto);
            _service.Update(produto);
             if (await _service.SaveChangesAsync())
               return Created($"api/Produto/{model.Id}", _mapper.Map<ProdutoModel>(produto));
             

            return BadRequest();

        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(string Id)
        {
            var produto = await _service.GetById(Id);
            if(produto == null)return NotFound();

            _service.Delete(produto);
             if(await _service.SaveChangesAsync())
                return Ok();
            return BadRequest();
        }
    }
}