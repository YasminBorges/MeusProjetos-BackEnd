namespace Domain.Entity
{
    public class Produto
    {
         public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Description { get; set; }
        public int Amount { get; set; }
        public float Price { get; set; }
    }
}