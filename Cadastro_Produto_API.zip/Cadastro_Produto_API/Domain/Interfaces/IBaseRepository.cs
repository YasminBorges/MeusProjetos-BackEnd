namespace Domain.Interfaces
{
    public interface IBaseRepository<T> where T : class
    {
         void Add(T entity);
         void Update(T entity);
         Task<T> GetById (string id);
         Task<IEnumerable<T>> GetAll();
         Task<bool> SaveChangesAsync(); 
         void Delete(T entity);
    }
}