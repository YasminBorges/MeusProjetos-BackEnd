namespace Domain.Models
{
    public class ProdutoModel
    {
         public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Description { get; set; }
        public int Amount { get; set; }
        public float Price { get; set; }
    }
}