using Cadastro_Produto_DB.Context;
using Cadastro_Produto_DB.Interface;
using Cadastro_Produto_DB.Models;
using Cadastro_Produto_DB.Repository;
using Microsoft.AspNetCore.Mvc;

namespace Cadastro_Produto_DB.Controllers
{
    public class ProdutoController : Controller
    {
        private readonly IRepository<ProdutoModel> _repo;
        private readonly DataContext _context;

        public ProdutoController(IRepository<ProdutoModel> repo,DataContext context)
        {
            _repo = repo;
            _context = context;
        }

        public async Task<IActionResult> Cadastro(ProdutoModel produto)
        {
           
              _repo.add(produto);
       
             await _repo.SaveChangesAsync();
             return RedirectToAction("Listar");
           
        }

        public async Task<IActionResult> Listar(){
           
          var produtos = await _repo.GetAll();
            return View(produtos);
        }


        public async Task<IActionResult> Editar(string id)
        {
            var produto = await _repo.GetById(id);
             
           if(produto != null){
                return View(produto);
            }
            else{
                return RedirectToAction("Listar");
            }
            
        }

         public async Task<IActionResult> Update(string id, ProdutoModel produto)
         {
             var prod = _context.Produto.Where(p => p.Id == produto.Id);
             _repo.Update(produto);
                await _repo.SaveChangesAsync();
                return RedirectToAction("Listar");
         }



        public async Task<IActionResult> Excluir(string id)
        {
            var produto = await _repo.GetById(id);
           if(produto == null) return NotFound();
           _repo.Delete(produto);
           if(await _repo.SaveChangesAsync())
          
           return RedirectToAction("Listar");
            return View(produto);
          

        }
    }
}