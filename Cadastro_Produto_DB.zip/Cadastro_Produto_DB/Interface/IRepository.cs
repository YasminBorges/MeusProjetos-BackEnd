namespace Cadastro_Produto_DB.Interface
{
    public interface IRepository<T> where T : class
    {
         void add(T entity);
         Task<IEnumerable<T>> GetAll();
         void Update(T entity);
         void Delete(T entity);
         Task<T> GetById(string id);
         Task<bool> SaveChangesAsync();
    }
}