using Cadastro_Produto_DB.Context;
using Cadastro_Produto_DB.Interface;
using Microsoft.EntityFrameworkCore;

namespace Cadastro_Produto_DB.Repository
{
    public class RepositoryBase<T> : IRepository<T> where T : class
    {
        private readonly DataContext _context;

        public RepositoryBase(DataContext context)
        {
            _context = context;
        }
        
        public void add(T entity)
        {
           _context.Add(entity);
        }

        public void Delete(T entity)
        {
            _context.Set<T>().Remove(entity);
        }

        public async Task<IEnumerable<T>> GetAll()
        {
           return await _context.Set<T>().ToListAsync();
        }

        public async Task<T> GetById(string id)
        {
           return await _context.Set<T>().FindAsync(id);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _context.SaveChangesAsync()) > 0;
        }

        public void Update(T entity)
        {
            _context.Set<T>().Update(entity);
        }
    }
}