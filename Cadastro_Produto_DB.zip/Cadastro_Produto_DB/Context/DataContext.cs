using Cadastro_Produto_DB.Models;
using Microsoft.EntityFrameworkCore;

namespace Cadastro_Produto_DB.Context
{
    public class DataContext : DbContext
    {
          public DataContext(DbContextOptions<DataContext> options):base(options){}
          public DbSet<ProdutoModel> Produto {get; set;}
    }
}